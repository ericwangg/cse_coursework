#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define     LINE_SIZE   1024

void my_error(char *s)
{
    fprintf(stderr, "Error: %s\n", s);
    perror("errno");
    exit(-1);
} 

// This funciton prints lines (in a file) that contain string s.
// assume all lines has at most (LINE_SIZE - 2) ASCII characters.
//
// Functions that may be called in this function:
// fopen(), fclose(), fgets(), fputs(), strstr() 
//
// Paramters:
//  s: the string
//  filename: the file to be searched
// Return values:
//  0:  success.
//  EOF: cannot open or close file.
int print_matched_lines(const char *s, const char *filename)
{
    // TODO
    
    // char *line = NULL;					// the specific line that contains the pattern
    // size_t buffer = 0;					// buffer for getline()
    FILE *fp;							// separate of file pointer intialization and use
    fp = fopen(filename, "r");			// open the "filename" file for reading
    char line[LINE_SIZE - 2];				// assuming all lines has at most LINE_SIZE - 2
	// char *buffer = NULL; 
    // char *getString = fgets(line, sizeof(line), fp);			THIS WAS CAUSING INF LOOP
    
    if(fp == NULL){							// file does not exist, some error
    	return EOF;							// send to end of file (EOF), cannot open/close
    }
    while(fgets(line, sizeof(line), fp) != NULL){			// continue search before end of file (EOF)
    	if(strstr(line, s) != NULL){
    		printf("%s", line);		// print that line that contains string "s"
    	}
    	else{
    		;						// pass
    	}
    }								// not need for else statement 
    
    								// NOT USED: strnstr searches "strMatch" characters of first occurrence in (strnstr is in C++)
    								// "line", as pointed by the matching pattern "s"
    	//printf("%s", line);		// print the line of match

    // while loop goes through entire file, until it hits EOF
    fclose(fp);						// always close the file after opening
    if(fp == NULL){
    	return EOF;					// file didn't close right, return error (EOF)
    }
	// if(fp == NULL){
	//   		return EOF;			
	//   }
    return 0;						// success.
}

int main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <string> <filename>\n", argv[0]);
        return -1;
    }

    // print_matched_lines() to print any lines in file argv[2] that contains arg[1]

    if (print_matched_lines(argv[1], argv[2])) {
        my_error("print_matched_lines() retunred a non_zero value.");
    }
    return 0;
}
